
const registros = JSON.parse(localStorage.getItem('registros')) || [];


const ejercicios = registros.filter(reg => reg.categoria === 'ejercicio');
const comidas = registros.filter(reg => reg.categoria === 'comida');
const suenos = registros.filter(reg => reg.categoria === 'sueño');


const ctxEjercicio = document.getElementById('graficoEjercicio').getContext('2d');
new Chart(ctxEjercicio, {
    type: 'bar',
    data: {
        labels: ejercicios.map(e => e.fecha),
        datasets: [{
            label: 'Duración de Ejercicio (minutos)',
            data: ejercicios.map(e => e.valor),
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        }]
    }
});


const ctxComida = document.getElementById('graficoComida').getContext('2d');
new Chart(ctxComida, {
    type: 'bar',
    data: {
        labels: comidas.map(c => c.fecha),
        datasets: [{
            label: 'Comida (kcal)',
            data: comidas.map(c => c.valor),
            backgroundColor: 'rgba(153, 102, 255, 0.2)',
            borderColor: 'rgba(153, 102, 255, 1)',
            borderWidth: 1
        }]
    }
});


const ctxSueno = document.getElementById('graficoSueno').getContext('2d');
new Chart(ctxSueno, {
    type: 'bar',
    data: {
        labels: suenos.map(s => s.fecha),
        datasets: [{
            label: 'Horas de Sueño',
            data: suenos.map(s => s.valor),
            backgroundColor: 'rgba(255, 159, 64, 0.2)',
            borderColor: 'rgba(255, 159, 64, 1)',
            borderWidth: 1
        }]
    }
});

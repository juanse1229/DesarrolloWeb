// Función para actualizar la tabla con los registros
function actualizarTabla() {
    // Obtener los registros del localStorage
    const registros = JSON.parse(localStorage.getItem('registros')) || [];

    // Obtener el cuerpo de la tabla
    const tbody = document.getElementById('tabla-registro').getElementsByTagName('tbody')[0];
    
    // Limpiar la tabla
    tbody.innerHTML = '';

    // Insertar filas para cada registro
    registros.forEach((registro) => {
        const row = tbody.insertRow();
        row.insertCell(0).textContent = registro.fecha;
        row.insertCell(1).textContent = registro.actividad;
        row.insertCell(2).textContent = registro.categoria;
        row.insertCell(3).textContent = registro.valor;
    });
}

// Manejo del formulario de registro
document.getElementById('registro-form').addEventListener('submit', function (event) {
    event.preventDefault();

    const fecha = document.getElementById('fecha').value;
    const actividad = document.getElementById('actividad').value;
    const valor = document.getElementById('valor').value;
    const categoria = document.getElementById('categoria').value;

    // Crear el objeto del registro
    const nuevoRegistro = { fecha, actividad, valor, categoria };

    // Obtener los registros almacenados en localStorage (si existen)
    let registros = JSON.parse(localStorage.getItem('registros')) || [];

    // Agregar el nuevo registro a la lista de registros
    registros.push(nuevoRegistro);

    // Guardar los registros actualizados en localStorage
    localStorage.setItem('registros', JSON.stringify(registros));

    // Limpiar el formulario
    document.getElementById('fecha').value = '';
    document.getElementById('actividad').value = '';
    document.getElementById('valor').value = '';

    // Actualizar la tabla con los nuevos registros
    actualizarTabla();
});

// Cargar la tabla al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    actualizarTabla();
});

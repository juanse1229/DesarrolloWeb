document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('registroForm').addEventListener('submit', function(e) {
        e.preventDefault(); // Evitar que el formulario se envíe automáticamente

        // Obtener los valores del formulario
        const nombre = document.getElementById('nombre').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        // Validación simple de los campos
        if (nombre && email && password) {
            // Guardar los datos del usuario en el localStorage (simulando una base de datos)
            localStorage.setItem('user', JSON.stringify({ nombre, email, password }));

            alert('Registro exitoso. Redirigiendo...');
            window.location.href = 'registro.html'; // Redirigir al registro de actividades
        } else {
            alert('Por favor, complete todos los campos.');
        }
    });
});
